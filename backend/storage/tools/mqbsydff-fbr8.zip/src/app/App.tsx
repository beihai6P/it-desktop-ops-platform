import { useState } from "react";
import { Bell, Search, ChevronRight, Home } from "lucide-react";
import { Sidebar } from "./components/Sidebar";
import { Dashboard } from "./components/Dashboard";
import { AssetList } from "./components/AssetList";
import { Reports } from "./components/Reports";
import { UserManagement } from "./components/UserManagement";
import { AuditLog } from "./components/AuditLog";

{/* MARKER-MAKE-KIT-INVOKED */}

const pageMeta: Record<string, { title: string; crumbs: string[] }> = {
  dashboard: { title: "仪表盘", crumbs: ["首页"] },
  "all-assets": { title: "全部资产", crumbs: ["资产管理", "全部资产"] },
  "in-use": { title: "在用资产", crumbs: ["资产管理", "在用资产"] },
  idle: { title: "闲置资产", crumbs: ["资产管理", "闲置资产"] },
  retired: { title: "报废资产", crumbs: ["资产管理", "报废资产"] },
  assets: { title: "全部资产", crumbs: ["资产管理", "全部资产"] },
  categories: { title: "资产分类", crumbs: ["资产分类"] },
  warehouse: { title: "入库 / 出库", crumbs: ["入库 / 出库"] },
  users: { title: "人员管理", crumbs: ["人员管理"] },
  reports: { title: "报表统计", crumbs: ["报表统计"] },
  audit: { title: "审计日志", crumbs: ["审计日志"] },
  settings: { title: "系统设置", crumbs: ["系统设置"] },
};

function PageContent({ page }: { page: string }) {
  if (page === "dashboard") return <Dashboard />;
  if (["all-assets", "assets", "in-use", "idle", "retired"].includes(page))
    return <AssetList filterStatus={page === "all-assets" || page === "assets" ? undefined : page} />;
  if (page === "reports") return <Reports />;
  if (page === "users") return <UserManagement />;
  if (page === "audit") return <AuditLog />;

  return (
    <div className="flex items-center justify-center h-64 bg-card rounded-lg border border-border">
      <div className="text-center">
        <p className="text-muted-foreground">页面开发中</p>
        <p className="text-xs text-muted-foreground mt-1">{pageMeta[page]?.title}</p>
      </div>
    </div>
  );
}

export default function App() {
  const [page, setPage] = useState("dashboard");
  const meta = pageMeta[page] ?? { title: page, crumbs: [page] };

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar active={page} onNavigate={setPage} />

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="h-14 bg-card border-b border-border flex items-center px-6 gap-4 shrink-0">
          {/* Breadcrumb */}
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground flex-1">
            <Home size={12} />
            {meta.crumbs.map((crumb, i) => (
              <span key={i} className="flex items-center gap-1.5">
                <ChevronRight size={11} />
                <span className={i === meta.crumbs.length - 1 ? "text-foreground font-medium" : ""}>{crumb}</span>
              </span>
            ))}
          </div>

          {/* Global search */}
          <div className="relative">
            <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              className="pl-8 pr-4 py-1.5 text-sm bg-input-background border border-border rounded-lg w-56 focus:outline-none focus:ring-2 focus:ring-ring/30 focus:w-72 transition-all"
              placeholder="全局搜索资产、用户..."
            />
          </div>

          {/* Notifications */}
          <button className="relative p-2 rounded-lg hover:bg-accent transition-colors">
            <Bell size={16} className="text-muted-foreground" />
            <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 bg-red-500 rounded-full" />
          </button>

          {/* Date */}
          <span className="text-xs text-muted-foreground">
            {new Date().toLocaleDateString("zh-CN", { year: "numeric", month: "long", day: "numeric", weekday: "long" })}
          </span>
        </header>

        {/* Page body */}
        <main className="flex-1 overflow-y-auto p-6">
          <PageContent page={page} />
        </main>
      </div>
    </div>
  );
}
