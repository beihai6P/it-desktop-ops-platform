import { useState } from "react";
import { Search, Plus, Edit2, Trash2, Shield, User } from "lucide-react";

const users = [
  { id: "U001", name: "张伟", dept: "研发部", role: "普通用户", assets: 3, email: "zhang.wei@company.com", phone: "138****8901", status: "正常", joinDate: "2021-03-15" },
  { id: "U002", name: "李娜", dept: "财务部", role: "普通用户", assets: 2, email: "li.na@company.com", phone: "139****2341", status: "正常", joinDate: "2020-07-22" },
  { id: "U003", name: "王明", dept: "IT部", role: "资产管理员", assets: 8, email: "wang.ming@company.com", phone: "135****6782", status: "正常", joinDate: "2019-05-10" },
  { id: "U004", name: "赵敏", dept: "IT部", role: "超级管理员", assets: 5, email: "zhao.min@company.com", phone: "137****9012", status: "正常", joinDate: "2018-11-01" },
  { id: "U005", name: "陈磊", dept: "运营部", role: "普通用户", assets: 1, email: "chen.lei@company.com", phone: "136****3456", status: "禁用", joinDate: "2022-02-18" },
  { id: "U006", name: "孙艳", dept: "市场部", role: "普通用户", assets: 2, email: "sun.yan@company.com", phone: "133****7890", status: "正常", joinDate: "2023-01-09" },
];

const roleColor: Record<string, string> = {
  超级管理员: "bg-purple-100 text-purple-700",
  资产管理员: "bg-blue-100 text-blue-700",
  普通用户: "bg-gray-100 text-gray-600",
};

export function UserManagement() {
  const [search, setSearch] = useState("");

  const filtered = users.filter(
    (u) => u.name.includes(search) || u.dept.includes(search) || u.email.includes(search)
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-foreground">人员管理</h2>
          <p className="text-xs text-muted-foreground mt-0.5">管理系统用户与权限</p>
        </div>
        <button className="flex items-center gap-1.5 px-3 py-1.5 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-blue-700 transition-colors">
          <Plus size={14} /> 新增用户
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[
          { label: "用户总数", value: users.length, color: "text-blue-600 bg-blue-50" },
          { label: "管理员", value: users.filter(u => u.role !== "普通用户").length, color: "text-purple-600 bg-purple-50" },
          { label: "禁用账号", value: users.filter(u => u.status === "禁用").length, color: "text-red-600 bg-red-50" },
        ].map((s) => (
          <div key={s.label} className="bg-card rounded-lg border border-border p-4 flex items-center gap-3">
            <div className={`p-2.5 rounded-lg ${s.color}`}>
              <User size={18} />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">{s.label}</p>
              <p className="text-2xl font-semibold">{s.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-card rounded-lg border border-border p-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="relative flex-1 max-w-xs">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              className="w-full pl-8 pr-3 py-1.5 text-sm bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring/30"
              placeholder="搜索姓名、部门、邮箱..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <select className="px-3 py-1.5 text-sm bg-input-background border border-border rounded-lg focus:outline-none">
            <option>全部角色</option>
            <option>超级管理员</option>
            <option>资产管理员</option>
            <option>普通用户</option>
          </select>
        </div>

        <table className="w-full">
          <thead className="border-b border-border">
            <tr>
              {["工号", "姓名", "部门", "角色", "持有资产", "邮箱", "入职日期", "状态", "操作"].map((h) => (
                <th key={h} className="pb-2 text-left text-xs text-muted-foreground font-medium">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((u, i) => (
              <tr key={u.id} className={`border-b border-border last:border-0 hover:bg-accent/50 transition-colors ${i % 2 === 1 ? "bg-muted/20" : ""}`}>
                <td className="py-3 text-xs font-mono text-primary">{u.id}</td>
                <td className="py-3 text-sm font-medium">{u.name}</td>
                <td className="py-3 text-xs text-muted-foreground">{u.dept}</td>
                <td className="py-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${roleColor[u.role]}`}>{u.role}</span>
                </td>
                <td className="py-3 text-xs text-center">{u.assets}</td>
                <td className="py-3 text-xs text-muted-foreground">{u.email}</td>
                <td className="py-3 text-xs text-muted-foreground">{u.joinDate}</td>
                <td className="py-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${u.status === "正常" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"}`}>
                    {u.status}
                  </span>
                </td>
                <td className="py-3">
                  <div className="flex items-center gap-1">
                    <button className="p-1 rounded hover:bg-purple-50 text-purple-600 transition-colors" title="权限管理">
                      <Shield size={13} />
                    </button>
                    <button className="p-1 rounded hover:bg-amber-50 text-amber-600 transition-colors">
                      <Edit2 size={13} />
                    </button>
                    <button className="p-1 rounded hover:bg-red-50 text-red-500 transition-colors">
                      <Trash2 size={13} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
