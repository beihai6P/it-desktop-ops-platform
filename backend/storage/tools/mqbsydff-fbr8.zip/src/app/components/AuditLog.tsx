import { useState } from "react";
import { Search, Filter, Shield } from "lucide-react";

const logs = [
  { id: "L0892", time: "2024-12-15 10:32:14", user: "张伟", ip: "192.168.1.45", action: "资产领用", target: "ThinkPad X1 Carbon (SN-2024-0892)", result: "成功" },
  { id: "L0891", time: "2024-12-15 10:15:07", user: "李娜", ip: "192.168.1.72", action: "资产归还", target: "MacBook Pro 14 (SN-2024-0743)", result: "成功" },
  { id: "L0890", time: "2024-12-15 09:48:33", user: "王明", ip: "192.168.1.11", action: "报修申请", target: "Dell PowerEdge R740 (SN-2023-1201)", result: "成功" },
  { id: "L0889", time: "2024-12-15 09:30:52", user: "赵敏", ip: "192.168.1.10", action: "新增资产", target: "HP EliteBook 840 (SN-2024-1102)", result: "成功" },
  { id: "L0888", time: "2024-12-15 09:12:18", user: "陈磊", ip: "192.168.1.98", action: "报废申请", target: "Lenovo ThinkCentre (SN-2019-0334)", result: "成功" },
  { id: "L0887", time: "2024-12-15 08:55:41", user: "赵敏", ip: "192.168.1.10", action: "修改用户权限", target: "用户：孙艳 角色→资产管理员", result: "成功" },
  { id: "L0886", time: "2024-12-15 08:40:29", user: "Unknown", ip: "203.45.67.89", action: "登录尝试", target: "账号：admin", result: "失败" },
  { id: "L0885", time: "2024-12-14 17:22:03", user: "王明", ip: "192.168.1.11", action: "导出报表", target: "2024年11月资产报表.xlsx", result: "成功" },
];

const actionColor: Record<string, string> = {
  资产领用: "text-blue-600",
  资产归还: "text-green-600",
  报修申请: "text-amber-600",
  新增资产: "text-purple-600",
  报废申请: "text-red-500",
  修改用户权限: "text-orange-600",
  登录尝试: "text-red-600",
  导出报表: "text-teal-600",
};

export function AuditLog() {
  const [search, setSearch] = useState("");

  const filtered = logs.filter(
    (l) => l.user.includes(search) || l.action.includes(search) || l.target.includes(search)
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-foreground">审计日志</h2>
          <p className="text-xs text-muted-foreground mt-0.5">系统操作完整记录，不可篡改</p>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-green-50 border border-green-200 rounded-lg">
          <Shield size={14} className="text-green-600" />
          <span className="text-xs text-green-700 font-medium">审计功能已启用</span>
        </div>
      </div>

      <div className="bg-card rounded-lg border border-border p-4">
        <div className="flex items-center gap-3 mb-4">
          <div className="relative flex-1 max-w-xs">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              className="w-full pl-8 pr-3 py-1.5 text-sm bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring/30"
              placeholder="搜索操作人、操作类型、对象..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <input type="date" className="px-3 py-1.5 text-sm bg-input-background border border-border rounded-lg focus:outline-none" defaultValue="2024-12-15" />
          <select className="px-3 py-1.5 text-sm bg-input-background border border-border rounded-lg focus:outline-none">
            <option>全部操作</option>
            <option>资产操作</option>
            <option>用户操作</option>
            <option>系统操作</option>
          </select>
          <select className="px-3 py-1.5 text-sm bg-input-background border border-border rounded-lg focus:outline-none">
            <option>全部结果</option>
            <option>成功</option>
            <option>失败</option>
          </select>
          <button className="flex items-center gap-1.5 px-3 py-1.5 text-sm border border-border rounded-lg hover:bg-accent transition-colors text-muted-foreground ml-auto">
            <Filter size={14} /> 高级筛选
          </button>
        </div>

        <table className="w-full">
          <thead className="border-b border-border">
            <tr>
              {["日志ID", "时间", "操作人", "IP地址", "操作类型", "操作对象", "结果"].map((h) => (
                <th key={h} className="pb-2 text-left text-xs text-muted-foreground font-medium">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((log, i) => (
              <tr key={log.id} className={`border-b border-border last:border-0 hover:bg-accent/50 transition-colors ${i % 2 === 1 ? "bg-muted/20" : ""}`}>
                <td className="py-2.5 text-xs font-mono text-muted-foreground">{log.id}</td>
                <td className="py-2.5 text-xs text-muted-foreground whitespace-nowrap">{log.time}</td>
                <td className="py-2.5 text-xs font-medium">{log.user}</td>
                <td className="py-2.5 text-xs font-mono text-muted-foreground">{log.ip}</td>
                <td className={`py-2.5 text-xs font-medium ${actionColor[log.action] ?? "text-foreground"}`}>{log.action}</td>
                <td className="py-2.5 text-xs text-muted-foreground max-w-xs truncate">{log.target}</td>
                <td className="py-2.5">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${log.result === "成功" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"}`}>
                    {log.result}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
