import { Monitor, Cpu, Package, AlertTriangle, TrendingUp, TrendingDown, Activity } from "lucide-react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const stats = [
  {
    label: "资产总数",
    value: "2,847",
    change: "+12",
    trend: "up",
    icon: <Package size={18} />,
    color: "bg-blue-50 text-blue-600",
  },
  {
    label: "在用资产",
    value: "2,104",
    change: "+8",
    trend: "up",
    icon: <Monitor size={18} />,
    color: "bg-green-50 text-green-600",
  },
  {
    label: "闲置资产",
    value: "431",
    change: "-3",
    trend: "down",
    icon: <Cpu size={18} />,
    color: "bg-amber-50 text-amber-600",
  },
  {
    label: "待处理告警",
    value: "23",
    change: "+5",
    trend: "up",
    icon: <AlertTriangle size={18} />,
    color: "bg-red-50 text-red-600",
  },
];

const areaData = [
  { month: "1月", 新增: 42, 退库: 12 },
  { month: "2月", 新增: 58, 退库: 18 },
  { month: "3月", 新增: 37, 退库: 9 },
  { month: "4月", 新增: 63, 退库: 21 },
  { month: "5月", 新增: 71, 退库: 15 },
  { month: "6月", 新增: 49, 退库: 24 },
  { month: "7月", 新增: 85, 退库: 17 },
  { month: "8月", 新增: 62, 退库: 19 },
  { month: "9月", 新增: 78, 退库: 22 },
  { month: "10月", 新增: 91, 退库: 28 },
  { month: "11月", 新增: 54, 退库: 14 },
  { month: "12月", 新增: 67, 退库: 20 },
];

const deptData = [
  { dept: "研发部", 资产数: 842 },
  { dept: "市场部", 资产数: 398 },
  { dept: "运营部", 资产数: 521 },
  { dept: "行政部", 资产数: 214 },
  { dept: "财务部", 资产数: 187 },
  { dept: "销售部", 资产数: 445 },
];

const pieData = [
  { name: "笔记本电脑", value: 731, color: "#2563eb" },
  { name: "台式机", value: 524, color: "#10b981" },
  { name: "服务器", value: 186, color: "#f59e0b" },
  { name: "网络设备", value: 312, color: "#8b5cf6" },
  { name: "外设", value: 1094, color: "#ec4899" },
];

const recentActivities = [
  { time: "10:32", user: "张伟", action: "领用", asset: "ThinkPad X1 Carbon", sn: "SN-2024-0892", status: "完成" },
  { time: "10:15", user: "李娜", action: "归还", asset: "MacBook Pro 14", sn: "SN-2024-0743", status: "完成" },
  { time: "09:48", user: "王明", action: "报修", asset: "Dell OptiPlex 7090", sn: "SN-2023-1201", status: "进行中" },
  { time: "09:30", user: "赵敏", action: "新增", asset: "HP EliteBook 840", sn: "SN-2024-1102", status: "完成" },
  { time: "09:12", user: "陈磊", action: "报废", asset: "Lenovo ThinkCentre", sn: "SN-2019-0334", status: "审批中" },
];

const statusColor: Record<string, string> = {
  完成: "bg-green-100 text-green-700",
  进行中: "bg-blue-100 text-blue-700",
  审批中: "bg-amber-100 text-amber-700",
};

const actionColor: Record<string, string> = {
  领用: "text-blue-600",
  归还: "text-green-600",
  报修: "text-amber-600",
  新增: "text-purple-600",
  报废: "text-red-600",
};

export function Dashboard() {
  return (
    <div className="space-y-5">
      {/* Stat cards */}
      <div className="grid grid-cols-4 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="bg-card rounded-lg border border-border p-4">
            <div className="flex items-start justify-between">
              <div className={`p-2 rounded-lg ${s.color}`}>{s.icon}</div>
              <span
                className={`flex items-center gap-1 text-xs ${
                  s.trend === "up" && s.label !== "待处理告警"
                    ? "text-green-600"
                    : s.trend === "up" && s.label === "待处理告警"
                    ? "text-red-500"
                    : "text-green-600"
                }`}
              >
                {s.trend === "up" ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                {s.change}
              </span>
            </div>
            <p className="mt-3 text-2xl font-semibold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-3 gap-4">
        {/* Area chart */}
        <div className="col-span-2 bg-card rounded-lg border border-border p-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-medium text-foreground">资产变动趋势</h3>
              <p className="text-xs text-muted-foreground">全年资产新增与退库数量</p>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
              <Activity size={12} />
              2024年
            </div>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={areaData}>
              <defs>
                <linearGradient id="colorAdd" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2563eb" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorReturn" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6, border: "1px solid #e2e8f0" }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Area type="monotone" dataKey="新增" stroke="#2563eb" fill="url(#colorAdd)" strokeWidth={2} />
              <Area type="monotone" dataKey="退库" stroke="#10b981" fill="url(#colorReturn)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart */}
        <div className="bg-card rounded-lg border border-border p-4">
          <div className="mb-4">
            <h3 className="font-medium text-foreground">资产类型分布</h3>
            <p className="text-xs text-muted-foreground">按设备类型统计</p>
          </div>
          <ResponsiveContainer width="100%" height={150}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={68} dataKey="value" paddingAngle={2}>
                {pieData.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {pieData.map((d) => (
              <div key={d.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full" style={{ background: d.color }} />
                  <span className="text-muted-foreground">{d.name}</span>
                </div>
                <span className="font-medium text-foreground">{d.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-3 gap-4">
        {/* Bar chart */}
        <div className="col-span-1 bg-card rounded-lg border border-border p-4">
          <div className="mb-4">
            <h3 className="font-medium text-foreground">部门资产分布</h3>
            <p className="text-xs text-muted-foreground">各部门持有资产数量</p>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={deptData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={false} tickLine={false} />
              <YAxis type="category" dataKey="dept" tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={false} tickLine={false} width={40} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
              <Bar dataKey="资产数" fill="#2563eb" radius={[0, 3, 3, 0]} barSize={14} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Recent activity */}
        <div className="col-span-2 bg-card rounded-lg border border-border p-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-medium text-foreground">最近操作记录</h3>
              <p className="text-xs text-muted-foreground">今日资产操作流水</p>
            </div>
            <button className="text-xs text-primary hover:underline">查看全部</button>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="pb-2 text-left text-xs text-muted-foreground font-medium">时间</th>
                <th className="pb-2 text-left text-xs text-muted-foreground font-medium">操作人</th>
                <th className="pb-2 text-left text-xs text-muted-foreground font-medium">操作</th>
                <th className="pb-2 text-left text-xs text-muted-foreground font-medium">资产名称</th>
                <th className="pb-2 text-left text-xs text-muted-foreground font-medium">序列号</th>
                <th className="pb-2 text-left text-xs text-muted-foreground font-medium">状态</th>
              </tr>
            </thead>
            <tbody>
              {recentActivities.map((row, i) => (
                <tr key={i} className="border-b border-border last:border-0 hover:bg-accent transition-colors">
                  <td className="py-2.5 text-xs text-muted-foreground">{row.time}</td>
                  <td className="py-2.5 text-xs font-medium">{row.user}</td>
                  <td className={`py-2.5 text-xs font-medium ${actionColor[row.action]}`}>{row.action}</td>
                  <td className="py-2.5 text-xs">{row.asset}</td>
                  <td className="py-2.5 text-xs text-muted-foreground font-mono">{row.sn}</td>
                  <td className="py-2.5">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${statusColor[row.status]}`}>
                      {row.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
