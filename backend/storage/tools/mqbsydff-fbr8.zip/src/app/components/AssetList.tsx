import { useState } from "react";
import {
  Search,
  Filter,
  Plus,
  Download,
  Upload,
  MoreHorizontal,
  ChevronLeft,
  ChevronRight,
  Edit2,
  Trash2,
  Eye,
} from "lucide-react";

interface Asset {
  id: string;
  name: string;
  category: string;
  sn: string;
  brand: string;
  model: string;
  dept: string;
  user: string;
  status: "在用" | "闲置" | "报修" | "报废";
  purchaseDate: string;
  value: string;
}

const allAssets: Asset[] = [
  { id: "A001", name: "笔记本电脑", category: "计算机", sn: "SN-2024-0892", brand: "联想", model: "ThinkPad X1", dept: "研发部", user: "张伟", status: "在用", purchaseDate: "2024-01-15", value: "¥8,500" },
  { id: "A002", name: "台式机", category: "计算机", sn: "SN-2024-0743", brand: "惠普", model: "EliteDesk 800", dept: "财务部", user: "李娜", status: "在用", purchaseDate: "2024-02-20", value: "¥5,200" },
  { id: "A003", name: "服务器", category: "服务器", sn: "SN-2023-1201", brand: "戴尔", model: "PowerEdge R740", dept: "IT部", user: "王明", status: "报修", purchaseDate: "2023-05-10", value: "¥45,000" },
  { id: "A004", name: "交换机", category: "网络设备", sn: "SN-2024-1102", brand: "思科", model: "Catalyst 2960", dept: "IT部", user: "赵敏", status: "在用", purchaseDate: "2024-03-08", value: "¥12,000" },
  { id: "A005", name: "打印机", category: "外设", sn: "SN-2022-0334", brand: "惠普", model: "LaserJet M404", dept: "行政部", user: "陈磊", status: "闲置", purchaseDate: "2022-08-15", value: "¥2,800" },
  { id: "A006", name: "显示器", category: "外设", sn: "SN-2024-0556", brand: "戴尔", model: "U2722D", dept: "市场部", user: "孙艳", status: "在用", purchaseDate: "2024-04-12", value: "¥3,200" },
  { id: "A007", name: "笔记本电脑", category: "计算机", sn: "SN-2024-0981", brand: "苹果", model: "MacBook Pro 14", dept: "设计部", user: "刘洋", status: "在用", purchaseDate: "2024-05-01", value: "¥18,000" },
  { id: "A008", name: "防火墙", category: "网络设备", sn: "SN-2023-0891", brand: "华为", model: "USG6550E", dept: "IT部", user: "黄静", status: "在用", purchaseDate: "2023-11-20", value: "¥28,000" },
  { id: "A009", name: "投影仪", category: "影音设备", sn: "SN-2021-0123", brand: "爱普生", model: "CB-2255U", dept: "培训部", user: "吴刚", status: "报废", purchaseDate: "2021-03-15", value: "¥4,500" },
  { id: "A010", name: "UPS电源", category: "电源设备", sn: "SN-2023-0654", brand: "山特", model: "C3KS", dept: "IT部", user: "郑杰", status: "在用", purchaseDate: "2023-09-05", value: "¥6,800" },
];

const statusStyle: Record<string, string> = {
  在用: "bg-green-100 text-green-700",
  闲置: "bg-amber-100 text-amber-700",
  报修: "bg-blue-100 text-blue-700",
  报废: "bg-red-100 text-red-700",
};

export function AssetList({ filterStatus }: { filterStatus?: string }) {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<string[]>([]);
  const pageSize = 8;

  const filtered = allAssets.filter((a) => {
    const matchSearch =
      a.name.includes(search) ||
      a.sn.includes(search) ||
      a.user.includes(search) ||
      a.dept.includes(search);
    const matchStatus = filterStatus
      ? filterStatus === "in-use"
        ? a.status === "在用"
        : filterStatus === "idle"
        ? a.status === "闲置"
        : filterStatus === "retired"
        ? a.status === "报废"
        : true
      : true;
    return matchSearch && matchStatus;
  });

  const totalPages = Math.ceil(filtered.length / pageSize);
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  const toggleSelect = (id: string) => {
    setSelected((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const allSelected = paged.every((a) => selected.includes(a.id));
  const toggleAll = () => {
    if (allSelected) setSelected((prev) => prev.filter((x) => !paged.map((a) => a.id).includes(x)));
    else setSelected((prev) => [...new Set([...prev, ...paged.map((a) => a.id)])]);
  };

  const pageTitle =
    filterStatus === "in-use"
      ? "在用资产"
      : filterStatus === "idle"
      ? "闲置资产"
      : filterStatus === "retired"
      ? "报废资产"
      : "全部资产";

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-foreground">{pageTitle}</h2>
          <p className="text-xs text-muted-foreground mt-0.5">共 {filtered.length} 条记录</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 px-3 py-1.5 text-sm border border-border rounded-lg hover:bg-accent transition-colors">
            <Upload size={14} /> 导入
          </button>
          <button className="flex items-center gap-1.5 px-3 py-1.5 text-sm border border-border rounded-lg hover:bg-accent transition-colors">
            <Download size={14} /> 导出
          </button>
          <button className="flex items-center gap-1.5 px-3 py-1.5 text-sm bg-primary text-primary-foreground rounded-lg hover:bg-blue-700 transition-colors">
            <Plus size={14} /> 新增资产
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-card rounded-lg border border-border p-4">
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-xs">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              className="w-full pl-8 pr-3 py-1.5 text-sm bg-input-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-ring/30"
              placeholder="搜索资产名称、序列号、使用人..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            />
          </div>
          <select className="px-3 py-1.5 text-sm bg-input-background border border-border rounded-lg focus:outline-none">
            <option>全部分类</option>
            <option>计算机</option>
            <option>服务器</option>
            <option>网络设备</option>
            <option>外设</option>
          </select>
          <select className="px-3 py-1.5 text-sm bg-input-background border border-border rounded-lg focus:outline-none">
            <option>全部部门</option>
            <option>研发部</option>
            <option>市场部</option>
            <option>IT部</option>
            <option>财务部</option>
          </select>
          <button className="flex items-center gap-1.5 px-3 py-1.5 text-sm border border-border rounded-lg hover:bg-accent transition-colors text-muted-foreground">
            <Filter size={14} /> 更多筛选
          </button>
          {selected.length > 0 && (
            <div className="flex items-center gap-2 ml-auto">
              <span className="text-xs text-muted-foreground">已选 {selected.length} 项</span>
              <button className="px-3 py-1.5 text-xs bg-red-50 text-red-600 border border-red-200 rounded-lg hover:bg-red-100 transition-colors">
                批量删除
              </button>
              <button className="px-3 py-1.5 text-xs bg-amber-50 text-amber-600 border border-amber-200 rounded-lg hover:bg-amber-100 transition-colors">
                批量报废
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="bg-card rounded-lg border border-border overflow-hidden">
        <table className="w-full">
          <thead className="bg-muted/50 border-b border-border">
            <tr>
              <th className="w-10 px-4 py-3">
                <input type="checkbox" checked={allSelected} onChange={toggleAll} className="rounded" />
              </th>
              {["资产编号", "名称", "类别", "序列号", "品牌/型号", "使用部门", "使用人", "状态", "采购日期", "价值", "操作"].map((h) => (
                <th key={h} className="px-3 py-3 text-left text-xs text-muted-foreground font-medium whitespace-nowrap">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {paged.map((asset, i) => (
              <tr
                key={asset.id}
                className={`border-b border-border last:border-0 hover:bg-accent/50 transition-colors ${
                  selected.includes(asset.id) ? "bg-blue-50" : i % 2 === 0 ? "bg-card" : "bg-muted/20"
                }`}
              >
                <td className="px-4 py-3">
                  <input
                    type="checkbox"
                    checked={selected.includes(asset.id)}
                    onChange={() => toggleSelect(asset.id)}
                    className="rounded"
                  />
                </td>
                <td className="px-3 py-3 text-xs font-mono text-primary">{asset.id}</td>
                <td className="px-3 py-3 text-sm font-medium">{asset.name}</td>
                <td className="px-3 py-3 text-xs text-muted-foreground">{asset.category}</td>
                <td className="px-3 py-3 text-xs font-mono text-muted-foreground">{asset.sn}</td>
                <td className="px-3 py-3 text-xs">{asset.brand} / {asset.model}</td>
                <td className="px-3 py-3 text-xs">{asset.dept}</td>
                <td className="px-3 py-3 text-xs">{asset.user}</td>
                <td className="px-3 py-3">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${statusStyle[asset.status]}`}>
                    {asset.status}
                  </span>
                </td>
                <td className="px-3 py-3 text-xs text-muted-foreground">{asset.purchaseDate}</td>
                <td className="px-3 py-3 text-xs font-medium">{asset.value}</td>
                <td className="px-3 py-3">
                  <div className="flex items-center gap-1">
                    <button className="p-1 rounded hover:bg-blue-50 text-blue-600 transition-colors">
                      <Eye size={13} />
                    </button>
                    <button className="p-1 rounded hover:bg-amber-50 text-amber-600 transition-colors">
                      <Edit2 size={13} />
                    </button>
                    <button className="p-1 rounded hover:bg-red-50 text-red-500 transition-colors">
                      <Trash2 size={13} />
                    </button>
                    <button className="p-1 rounded hover:bg-accent text-muted-foreground transition-colors">
                      <MoreHorizontal size={13} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          显示第 {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, filtered.length)} 条，共 {filtered.length} 条
        </p>
        <div className="flex items-center gap-1">
          <button
            disabled={page === 1}
            onClick={() => setPage((p) => p - 1)}
            className="p-1.5 rounded border border-border hover:bg-accent disabled:opacity-40 transition-colors"
          >
            <ChevronLeft size={14} />
          </button>
          {Array.from({ length: totalPages }, (_, i) => (
            <button
              key={i}
              onClick={() => setPage(i + 1)}
              className={`w-7 h-7 text-xs rounded border transition-colors ${
                page === i + 1
                  ? "bg-primary text-primary-foreground border-primary"
                  : "border-border hover:bg-accent"
              }`}
            >
              {i + 1}
            </button>
          ))}
          <button
            disabled={page === totalPages}
            onClick={() => setPage((p) => p + 1)}
            className="p-1.5 rounded border border-border hover:bg-accent disabled:opacity-40 transition-colors"
          >
            <ChevronRight size={14} />
          </button>
        </div>
      </div>
    </div>
  );
}
