import {
  LayoutDashboard,
  Monitor,
  Cpu,
  Package,
  Users,
  FileBarChart2,
  Settings,
  Bell,
  ChevronDown,
  LogOut,
  ShieldCheck,
} from "lucide-react";

interface NavItem {
  icon: React.ReactNode;
  label: string;
  id: string;
  badge?: number;
  children?: { label: string; id: string }[];
}

const navItems: NavItem[] = [
  { icon: <LayoutDashboard size={16} />, label: "仪表盘", id: "dashboard" },
  {
    icon: <Monitor size={16} />,
    label: "资产管理",
    id: "assets",
    children: [
      { label: "全部资产", id: "all-assets" },
      { label: "在用资产", id: "in-use" },
      { label: "闲置资产", id: "idle" },
      { label: "报废资产", id: "retired" },
    ],
  },
  { icon: <Cpu size={16} />, label: "资产分类", id: "categories" },
  { icon: <Package size={16} />, label: "入库 / 出库", id: "warehouse" },
  { icon: <Users size={16} />, label: "人员管理", id: "users" },
  { icon: <FileBarChart2 size={16} />, label: "报表统计", id: "reports", badge: 3 },
  { icon: <ShieldCheck size={16} />, label: "审计日志", id: "audit" },
  { icon: <Settings size={16} />, label: "系统设置", id: "settings" },
];

interface SidebarProps {
  active: string;
  onNavigate: (id: string) => void;
}

export function Sidebar({ active, onNavigate }: SidebarProps) {
  const isChildActive = (item: NavItem) =>
    item.children?.some((c) => c.id === active) || active === item.id;

  return (
    <aside className="flex flex-col w-56 shrink-0 h-full bg-sidebar text-sidebar-foreground border-r border-sidebar-border">
      {/* Logo */}
      <div className="flex items-center gap-2 px-5 h-14 border-b border-sidebar-border shrink-0">
        <div className="w-7 h-7 rounded-lg bg-sidebar-primary flex items-center justify-center shrink-0">
          <Monitor size={14} className="text-white" />
        </div>
        <span className="font-semibold tracking-tight text-foreground">
          IT资产管理
        </span>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {navItems.map((item) => {
          const expanded = isChildActive(item);
          return (
            <div key={item.id}>
              <button
                onClick={() => onNavigate(item.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm transition-all duration-150 cursor-pointer ${
                  active === item.id && !item.children
                    ? "bg-sidebar-primary text-white shadow-sm"
                    : expanded && item.children
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-muted-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:translate-x-0.5"
                }`}
              >
                <span className="shrink-0">{item.icon}</span>
                <span className="flex-1 text-left">{item.label}</span>
                {item.badge && (
                  <span className="bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full leading-none">
                    {item.badge}
                  </span>
                )}
                {item.children && (
                  <ChevronDown
                    size={13}
                    className={`transition-transform ${expanded ? "rotate-180" : ""}`}
                  />
                )}
              </button>
              {item.children && expanded && (
                <div className="mt-0.5 ml-6 border-l border-sidebar-border pl-3 space-y-0.5">
                  {item.children.map((child) => (
                    <button
                      key={child.id}
                      onClick={() => onNavigate(child.id)}
                      className={`w-full text-left px-2 py-1.5 rounded-lg text-sm transition-all duration-150 cursor-pointer ${
                        active === child.id
                          ? "text-sidebar-primary font-semibold bg-sidebar-accent"
                          : "text-muted-foreground hover:text-sidebar-accent-foreground hover:bg-sidebar-accent hover:translate-x-0.5"
                      }`}
                    >
                      {child.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* User */}
      <div className="px-3 py-3 border-t border-sidebar-border">
        <div className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-sidebar-accent cursor-pointer transition-all duration-150 group">
          <div className="w-7 h-7 rounded-full bg-sidebar-primary flex items-center justify-center text-white text-xs font-semibold shrink-0">
            管
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-foreground truncate">管理员</p>
            <p className="text-xs text-muted-foreground truncate">admin@company.com</p>
          </div>
          <LogOut size={14} className="text-muted-foreground shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" />
        </div>
      </div>
    </aside>
  );
}
