import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";
import { TrendingUp, Package, DollarSign, AlertCircle } from "lucide-react";

const monthlyData = [
  { month: "1月", 采购: 320000, 维修: 45000, 报废: 28000 },
  { month: "2月", 采购: 480000, 维修: 32000, 报废: 15000 },
  { month: "3月", 采购: 260000, 维修: 58000, 报废: 42000 },
  { month: "4月", 采购: 590000, 维修: 27000, 报废: 31000 },
  { month: "5月", 采购: 410000, 维修: 63000, 报废: 18000 },
  { month: "6月", 采购: 350000, 维修: 41000, 报废: 25000 },
];

const utilizationData = [
  { dept: "研发部", 利用率: 94 },
  { dept: "市场部", 利用率: 82 },
  { dept: "运营部", 利用率: 88 },
  { dept: "行政部", 利用率: 71 },
  { dept: "财务部", 利用率: 79 },
  { dept: "销售部", 利用率: 85 },
];

const agingData = [
  { name: "1年以内", value: 412, color: "#10b981" },
  { name: "1-3年", value: 987, color: "#2563eb" },
  { name: "3-5年", value: 634, color: "#f59e0b" },
  { name: "5年以上", value: 814, color: "#ef4444" },
];

const kpis = [
  { label: "本月采购总额", value: "¥41.0万", change: "+12.3%", up: true, icon: <DollarSign size={16} /> },
  { label: "资产利用率", value: "83.2%", change: "+2.1%", up: true, icon: <TrendingUp size={16} /> },
  { label: "待报废资产", value: "814", change: "+28", up: false, icon: <Package size={16} /> },
  { label: "维修申请", value: "47", change: "+5", up: false, icon: <AlertCircle size={16} /> },
];

export function Reports() {
  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-foreground">报表统计</h2>
        <p className="text-xs text-muted-foreground mt-0.5">2024年资产运营数据汇总</p>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-4 gap-4">
        {kpis.map((k) => (
          <div key={k.label} className="bg-card rounded-lg border border-border p-4 flex items-center gap-3">
            <div className="p-2 bg-primary/10 text-primary rounded-lg shrink-0">{k.icon}</div>
            <div>
              <p className="text-xs text-muted-foreground">{k.label}</p>
              <p className="text-xl font-semibold mt-0.5">{k.value}</p>
              <p className={`text-xs mt-0.5 ${k.up ? "text-green-600" : "text-red-500"}`}>{k.change} 较上月</p>
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-card rounded-lg border border-border p-4">
          <h3 className="font-medium mb-1">月度费用分析</h3>
          <p className="text-xs text-muted-foreground mb-4">采购 / 维修 / 报废费用（元）</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthlyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={false} tickLine={false} tickFormatter={(v) => `${v / 10000}万`} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} formatter={(v: number) => `¥${v.toLocaleString()}`} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="采购" fill="#2563eb" radius={[3, 3, 0, 0]} barSize={12} />
              <Bar dataKey="维修" fill="#f59e0b" radius={[3, 3, 0, 0]} barSize={12} />
              <Bar dataKey="报废" fill="#ef4444" radius={[3, 3, 0, 0]} barSize={12} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card rounded-lg border border-border p-4">
          <h3 className="font-medium mb-1">部门资产利用率</h3>
          <p className="text-xs text-muted-foreground mb-4">各部门在用资产利用率统计</p>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={utilizationData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="dept" tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#6b7280" }} axisLine={false} tickLine={false} domain={[60, 100]} tickFormatter={(v) => `${v}%`} />
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} formatter={(v: number) => `${v}%`} />
              <Line type="monotone" dataKey="利用率" stroke="#2563eb" strokeWidth={2} dot={{ fill: "#2563eb", r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-card rounded-lg border border-border p-4">
          <h3 className="font-medium mb-1">资产使用年限分布</h3>
          <p className="text-xs text-muted-foreground mb-4">按购置时间分类统计</p>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={agingData} cx="50%" cy="50%" outerRadius={65} dataKey="value" paddingAngle={2}>
                {agingData.map((d, i) => <Cell key={i} fill={d.color} />)}
              </Pie>
              <Tooltip contentStyle={{ fontSize: 12, borderRadius: 6 }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 mt-3">
            {agingData.map((d) => (
              <div key={d.name} className="flex items-center gap-1.5 text-xs">
                <div className="w-2 h-2 rounded-full shrink-0" style={{ background: d.color }} />
                <span className="text-muted-foreground">{d.name}</span>
                <span className="ml-auto font-medium">{d.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="col-span-2 bg-card rounded-lg border border-border p-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-medium">资产折旧明细</h3>
              <p className="text-xs text-muted-foreground">高价值资产账面价值追踪</p>
            </div>
            <button className="text-xs px-3 py-1.5 bg-primary/10 text-primary rounded-lg hover:bg-primary/20 transition-colors">
              导出报表
            </button>
          </div>
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                {["资产名称", "原值", "已折旧", "净值", "使用年限", "折旧率"].map((h) => (
                  <th key={h} className="pb-2 text-left text-xs text-muted-foreground font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                { name: "PowerEdge R740 服务器", orig: "¥45,000", dep: "¥13,500", net: "¥31,500", years: "3年", rate: "30%" },
                { name: "MacBook Pro 16寸", orig: "¥22,000", dep: "¥4,400", net: "¥17,600", years: "1年", rate: "20%" },
                { name: "USG6550E 防火墙", orig: "¥28,000", dep: "¥5,600", net: "¥22,400", years: "1年", rate: "20%" },
                { name: "Catalyst 2960 交换机", orig: "¥12,000", dep: "¥2,400", net: "¥9,600", years: "1年", rate: "20%" },
                { name: "UPS C3KS 电源", orig: "¥6,800", dep: "¥2,040", net: "¥4,760", years: "2年", rate: "30%" },
              ].map((row, i) => (
                <tr key={i} className="border-b border-border last:border-0 hover:bg-accent/40 transition-colors">
                  <td className="py-2.5 text-sm">{row.name}</td>
                  <td className="py-2.5 text-xs font-medium">{row.orig}</td>
                  <td className="py-2.5 text-xs text-red-500">{row.dep}</td>
                  <td className="py-2.5 text-xs text-green-600 font-medium">{row.net}</td>
                  <td className="py-2.5 text-xs text-muted-foreground">{row.years}</td>
                  <td className="py-2.5 text-xs text-muted-foreground">{row.rate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
