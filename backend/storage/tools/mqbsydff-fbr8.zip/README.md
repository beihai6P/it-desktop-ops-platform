
  # IT资产管理系统UI

  This is a code bundle for IT资产管理系统UI. The original project is available at https://www.figma.com/design/H6q2EDeQ5K0L5TJUx99hYP/IT%E8%B5%84%E4%BA%A7%E7%AE%A1%E7%90%86%E7%B3%BB%E7%BB%9FUI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  